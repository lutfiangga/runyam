<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <?php $this->load->view('layout/link'); ?>
</head>

<body>
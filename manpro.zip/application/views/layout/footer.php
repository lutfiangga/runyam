 
 <footer class="footer">
     <div class="container-fluid">
         <div class="row text-muted">
             <div class="col-12 text-center">
                 <p class="mb-0">
                     <a class="text-muted" href="#"><strong>Copyright &copy;Kelompok 1 Capstone Project <?= date('Y'); ?>. All Right Reserved</strong></a>
                 </p>
             </div>
         </div>
     </div>
 </footer>
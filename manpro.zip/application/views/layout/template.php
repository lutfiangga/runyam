<?php $this->load->view('layout/header')?>
<?php $this->load->view('layout/content')?>
<!-- <?php $this->load->view('layout/footer')?> -->

<div class="container-fluid p-0">

    <div class="mb-3">
        <h1 class="h3 d-inline align-middle">Application &gt; <?= $sub; ?></h1>
        <a class="badge bg-dark text-white ms-2" href="upgrade-to-pro.html">
            Tambah Data Sampah
        </a>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title">Tambah Sampah</h5>
                    <h6 class="card-subtitle text-muted">tambah data sampah yang dikelola</h6>
                </div>
                <div class="card-body">

                    <form method="POST" action="<?= site_url('Sampah/save') ?>" enctype="multipart/form-data">
                        <div class="row">

                            <div class="col-12">
                                <label for="tanggal" class="form-label">Tanggal:</label>
                                <input type="date" class="form-control" id="tanggal" name="tanggal" placeholder="Contoh : 12/12/2012" required>
                            </div>
                            <div class="mt-4 col-12 col-sm-6 col-md-6">
                                <label for="kategori" class="form-label">Kategori:</label>
                                <input type="text" class="form-control" id="kategori" name="kategori" placeholder="Contoh : Organik" required>
                            </div>
                            <div class="mt-4 col-12 col-sm-6 col-md-6">
                                <label for="jumlah" class="form-label">Jumlah:</label>
                                <div class="input-group">
                                    <input type="text" id="jumlah" name="jumlah" placeholder="1132" class="form-control" aria-label="jumlah" required>
                                    <span class="input-group-text">Kg</span>
                                </div>
                            </div>
                        </div>
                        <div class="d-flex justify-content-center gap-4 mt-4">
                            <a href="<?= site_url('Sampah') ?>" class="btn btn-secondary me-2">Batal</a>
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>

</div>
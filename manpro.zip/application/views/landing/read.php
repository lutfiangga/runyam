<?php $this->load->view("landing/components/header") ?>
<?php $this->load->view("landing/components/feature") ?>
<?php $this->load->view("landing/components/faq") ?>
<?php $this->load->view("landing/components/contact") ?>

<?php
defined('BASEPATH') or exit('No direct script access allowed');

$config['canonical_url']    = null;
$config['site_title']       = "Site Title";
$config['site_description'] = "Site Description";
$config['site_image']       = null;
$config['twitter_user']     = "@tw_username";
$config['fb_app_id']        = null;
$config['fb_page_id']       = null;
